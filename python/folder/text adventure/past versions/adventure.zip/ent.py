
#inventory
class inventory:
    money = 0
    health = 20
    energy = 100
    contents = []

#loot
class basicSword:
    name ='basic sword'
    damage = 3
    damageType = 'kinetic'
    durability = 5


class basicPick:
    name = 'basic pickaxe'
    damage = 3
    damageType = 'mining'
    durability = 5

class ironOre:
    name = 'iron ore'
    damage = 2

class coal:
    name = 'coal'
    damage = 1

class stone:
    name = 'stone'
    damage = 1
    durability = 1

rockLoot = [ironOre, coal, coal, stone, stone, stone, stone]

basicLoot = [basicPick, basicSword, ironOre, stone, ironOre] 

loot = [basicLoot, rockLoot]

#Enemies
class skeleton:
    name = 'skeleton'
    health = 5
    damage = 1
    damageType = 'kinetic'
    loot = basicLoot
    points = 2
    accuracy = 6
    trFaAtt = True

class rock:
     name = 'rock'
     health = 3
     damage = 0
     loot = rockLoot
     points = 1
     accuracy = 0
     trFaAtt = False

enemies = [skeleton, rock]