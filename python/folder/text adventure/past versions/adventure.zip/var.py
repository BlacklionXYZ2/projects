#important variables
response = None
chests = []
diffScalar = 0.2
chest = []
nearbyEnemies = []
roomOptions = []
nearbyItems = []
droppedItems = []
room = 0
move = True